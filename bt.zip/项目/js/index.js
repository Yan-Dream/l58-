var img = document.getElementsByClassName('banner-slide'),
    index=0,
    timer;
 
timer=setInterval(function(){
    index++;
    if(index>=img.length){
        index=0;
    }
    changeImg();
},3000)

 
function changeImg(){
    for(var i=0;i<img.length;i++){
        img[i].style.display='none';
    }
    img[index].style.display='block';
}
changeImg();
// 首页轮播图
