$(document).ready(function(){
    $.ajax({
        url:"http://127.0.0.1:5500/js/navnew.json",
        type:"get",
        dataType:"json",
        success:function(res){
            console.log(res);
            $.each(res,function(index,value){
                $(".navnew").append("<li><a href='"+value.loca+"'>"+value.name+"</a></li>")
            })
        },
        error:function(){
            console.log("请求失败")
        }
    })
})
// 获取导航接口
$(document).ready(function(){
    $.ajax({
        url:"http://127.0.0.1:5500/js/banner.json",
        type:"get",
        dataType:"json",
        success:function(res){
            console.log(res);
            $.each(res,function(index,value){
                $(".banner").append("<a href='#'><div class='banner-slide "+value.class+"'><img src='http://127.0.0.1:5500/"+value.imag+"'></div></a>")
            })
        },
        error:function(){
            console.log("请求失败")
        }
    })
})
// banner图获取
$(document).ready(function(){
    $.ajax({
        url:"http://127.0.0.1:5500/js/xbpp.json",
        type:"get",
        dataType:"json",
        success:function(res){
            console.log(res);
            $.each(res,function(index,value){
                $(".i_brd_m").append("<li class='col-lg-4 col-xs-12'><h6>"+value.hxb+"</h6><a href='#'><img src='http://127.0.0.1:5500/"+value.xbig+"'></a></li>")
            })
        },
        error:function(){
            console.log("请求失败")
        }
    })
})

// 关于信本页面
$(document).ready(function(){
    $.ajax({
        url:"http://127.0.0.1:5500/js/s_nav.json",
        type:"get",
        dataType:"json",
        success:function(res){
            console.log(res);
            $.each(res,function(index,value){
                $(".s_nav").append("<li class='"+value.xbcl+"'><a href='#'><em>"+value.gyxb+"</em></a></li>")
            })
        },
        error:function(){
            console.log("请求失败")
        }
    })
})